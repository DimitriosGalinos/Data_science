# input:   1) datamatrix as loaded by numpy.loadtxt('dataset.txt')
#	       2) an integer d specifying the number of dimensions for the output 
#            (most commonly used are 2 or 3)
# output:  1) an N x d numpy array containing the d coordinates of the N 
#             original datapoints projected onto the top d PCs
#

import numpy as np
from pca import pca

def mds(data, d):
    eigenValues, eigenVectors, indexes=pca(data)
    lenght=np.size(data, 1)
    # Centrailizing our dataset
    centralized=np.array(data)
    for xx in range(lenght):
        centralized[:,xx]=data[:,xx]-np.mean(data[:,xx])
    # Finding the new d-dimension datatset based on the d PCs
    pcstack=np.dot(centralized, eigenVectors[:,:d])
    return pcstack
