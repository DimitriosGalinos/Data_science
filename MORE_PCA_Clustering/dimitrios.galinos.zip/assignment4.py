# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 22:37:27 2020

@author: Dimitrios Galinos
"""

import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from pca import pca
from mds import mds
import matplotlib
from sklearn.cluster import KMeans 
from sklearn.preprocessing import StandardScaler
from math import sqrt

# Reading our data sets
diatoms=np.loadtxt("diatoms.txt")
toydata=np.loadtxt("pca_toydata.txt")
train_data=np.loadtxt("IDSWeedCropTrain.csv", delimiter=",")
test_data=np.loadtxt("IDSWeedCropTest.csv", delimiter=",")
# Split data into variables and labels
XTrain=train_data[:,:-1]
YTrain=train_data[:,-1]
XTest=test_data[:,:-1]
YTest=test_data[:,-1]

################################ Exercise 1 ###################################

# Split the diatoms into X and Y coordinates
le1=len(diatoms)
le2=int(np.size(diatoms)/le1)
diatomsX=[]
diatomsY=[]
for xx in range(le2):
    if xx%2==0:
        diatomsX.append(diatoms[:,xx])
    else:
        diatomsY.append(diatoms[:,xx])   
diatomsX=np.vstack(diatomsX).T
diatomsY=np.vstack(diatomsY).T

# Connect the first with the last coordinate
diatomsX = np.c_[diatomsX,diatomsX[:,0]]
diatomsY = np.c_[diatomsY,diatomsY[:,0]]

# Plot the first cell
plt.plot(diatomsX[0], diatomsY[0])
plt.xlabel('X coordinate')
plt.ylabel('Y coordinate')
plt.axis('equal')
plt.show()

# Plot all the cells
for xx in range(1, le1):
    plt.plot(diatomsX[xx], diatomsY[xx])
plt.xlabel('X coordinate')
plt.ylabel('Y coordinate')
plt.axis('equal')
plt.show()

################################ Exercise 2 ###################################

# Find the mean Diatom shape
meanDiatom=np.mean(diatoms, axis=0)

# PCA on the diatoms
eigenValuesDiatom, eigenVectorsDiatom, indexesDiatom=pca(diatoms)

# Prepare the coordinates for the first 3 PCs
vector1=eigenVectorsDiatom[:,0]
vector2=eigenVectorsDiatom[:,1]
vector3=eigenVectorsDiatom[:,2]
diatoms1X=[]
diatoms1Y=[]
diatoms2X=[]
diatoms2Y=[]
diatoms3X=[]
diatoms3Y=[]
diatomsmeanX=[]
diatomsmeanY=[]
for xx in range(len(vector1)):
    if xx%2==0:
        diatoms1X.append(vector1[xx])
        diatoms2X.append(vector2[xx])
        diatoms3X.append(vector3[xx])
        diatomsmeanX.append(meanDiatom[xx])
    else:
        diatoms1Y.append(vector1[xx])   
        diatoms2Y.append(vector2[xx])  
        diatoms3Y.append(vector3[xx])  
        diatomsmeanY.append(meanDiatom[xx])
        
# Connect the last with the first coordinate
diatoms1X=np.append(diatoms1X,diatoms1X[0])
diatoms2X=np.append(diatoms2X,diatoms2X[0])
diatoms3X =np.append(diatoms3X,diatoms3X[0]) 
diatomsmeanX=np.append(diatomsmeanX,diatomsmeanX[0])
diatoms1Y=np.append(diatoms1Y,diatoms1Y[0])
diatoms2Y=np.append(diatoms2Y,diatoms2Y[0])
diatoms3Y=np.append(diatoms3Y,diatoms3Y[0])
diatomsmeanY=np.append(diatomsmeanY,diatomsmeanY[0])

# Prepare the eigenvectors and Standard deviations
var1=eigenValuesDiatom[0]
var2=eigenValuesDiatom[1]
var3=eigenValuesDiatom[2]
sigma1=sqrt(var1)
sigma2=sqrt(var2)
sigma3=sqrt(var3)

# Plot of the first PC Diatom
plt.plot(diatomsmeanX-np.multiply((2*sigma1),diatoms1X), 
         diatomsmeanY-np.multiply((2*sigma1),diatoms1Y), 'navy')
plt.plot(diatomsmeanX-np.multiply((sigma1),diatoms1X), 
         diatomsmeanY-np.multiply((sigma1),diatoms1Y), 'blue')
plt.plot(diatomsmeanX, diatomsmeanY, 'dodgerblue')
plt.plot(diatomsmeanX+np.multiply((sigma1),diatoms1X), 
         diatomsmeanY+np.multiply((sigma1),diatoms1Y), 'lightskyblue')
plt.plot(diatomsmeanX+np.multiply((2*sigma1),diatoms1X), 
         diatomsmeanY+np.multiply((2*sigma1),diatoms1Y), 'paleturquoise')
plt.xlabel('X coordinate')
plt.ylabel('Y coordinate')
plt.axis('equal')
plt.show()

# Plot of the second PC Diatom
plt.plot(diatomsmeanX-np.multiply((2*sigma2),diatoms2X), 
         diatomsmeanY-np.multiply((2*sigma2),diatoms2Y), 'navy')
plt.plot(diatomsmeanX-np.multiply((sigma2),diatoms2X), 
         diatomsmeanY-np.multiply((sigma2),diatoms2Y), 'blue')
plt.plot(diatomsmeanX, diatomsmeanY, 'dodgerblue')
plt.plot(diatomsmeanX+np.multiply((sigma2),diatoms2X), 
         diatomsmeanY+np.multiply((sigma2),diatoms2Y), 'lightskyblue')
plt.plot(diatomsmeanX+np.multiply((2*sigma2),diatoms2X), 
         diatomsmeanY+np.multiply((2*sigma2),diatoms2Y), 'paleturquoise')
plt.xlabel('X coordinate')
plt.ylabel('Y coordinate')
plt.axis('equal')
plt.show()

# Plot of the thrid PC Diatom
plt.plot(diatomsmeanX-np.multiply((2*sigma3),diatoms3X), 
         diatomsmeanY-np.multiply((2*sigma3),diatoms3Y), 'navy')
plt.plot(diatomsmeanX-np.multiply((sigma3),diatoms3X), 
         diatomsmeanY-np.multiply((sigma3),diatoms3Y), 'blue')
plt.plot(diatomsmeanX, diatomsmeanY, 'dodgerblue')
plt.plot(diatomsmeanX+np.multiply((sigma3),diatoms3X), 
         diatomsmeanY+np.multiply((sigma3),diatoms3Y), 'lightskyblue')
plt.plot(diatomsmeanX+np.multiply((2*sigma3),diatoms3X), 
         diatomsmeanY+np.multiply((2*sigma3),diatoms3Y), 'paleturquoise')
plt.xlabel('X coordinate')
plt.ylabel('Y coordinate')
plt.axis('equal')
plt.show()

################################ Exercise 3 ###################################

# b)

# Standardize the data before perfoming PCA
scaler=StandardScaler()
toydata=scaler.fit_transform(toydata)

# Get the dataset without the last 2 datapoints
lenght=len(toydata)
toydata_clean=toydata[:(lenght-2)]

"""
# Checking sklearn's PCA results

pca_toy = PCA(n_components=2)
toy_2d=pca_toy.fit_transform(toydata)
plt.scatter(toy_2d[:,0], toy_2d[:,1])
plt.xlabel('1st Principal component (Feature 1)')
plt.ylabel('2nd Principal component (Feature 2)')
plt.show()

toy_2d=pca_toy.fit_transform(toydata_clean)
plt.scatter(toy_2d[:,0], toy_2d[:,1])
plt.xlabel('1st Principal component (Feature 1)')
plt.ylabel('2nd Principal component (Feature 2)')
plt.show()
"""

# Doing it with my own implementation (yields the same exact plots)
toy_2d=mds(toydata, 2)
plt.scatter(toy_2d[:,0], toy_2d[:,1])
plt.xlabel('1st Principal component (Feature 1)')
plt.ylabel('2nd Principal component (Feature 2)')
plt.show()

toy_2d=mds(toydata_clean, 2)
plt.scatter(toy_2d[:,0], toy_2d[:,1])
plt.xlabel('1st Principal component (Feature 1)')
plt.ylabel('2nd Principal component (Feature 2)')
plt.show()

"""
The hidden structure is an ellipse, the difference between the two projections
is the existance of a point in the center of the axes [0,0] in the full 
dataset, while this point disappears in the second projection.
Since the last 2 datapoints where both [0,0,0,0] it makes sense that their 2D
projection would be around [0,0] so by removing those [0,0,0,0] points the
projection should no longer have the [0,0] spots as well.
"""

################################ Exercise 4 ###################################

# Standardize the data
meanTrain=np.mean(XTrain, axis=0)
stdTrain=np.std(XTrain, axis=0)
XTrain=np.subtract(XTrain, meanTrain)/stdTrain

# Prepare the data for the KMeans
label=YTrain
start=np.vstack((XTrain[0,:], XTrain[1,:]))

# KMeans Clustering
kmeans=KMeans(n_clusters=2, n_init=1, init=start, algorithm="full").fit(XTrain)

# Cluster Centers
cc=kmeans.cluster_centers_

# Multidimensional scaling into the first 2 dimensions (PCs) for the dataset
weed_2d=mds(XTrain, 2)

# Scaling the cluster centers I found earlier into the first two PCs of the
# dataset
eigenValues, eigenVectors, indexes=pca(XTrain)
pcstack=np.dot(cc, eigenVectors[:,:2])

# Plotting of the two cluster centers and the dataset by projecting them in 
# their first main 2 PCs
colors=["lightgreen", "orange"]
plt.scatter(weed_2d[:,0], weed_2d[:,1], c=label, 
            cmap=matplotlib.colors.ListedColormap(colors))
plt.scatter(pcstack[0,0], pcstack[0,1], c="red", s=200)
plt.scatter(pcstack[1,0], pcstack[1,1], c="blue", s=200)
plt.xlabel('1st Principal component (Feature 1)')
plt.ylabel('2nd Principal component (Feature 2)')
plt.show()

"""
It looks like we got meaningful clusters since they seem to be close to the 
centers of each different label
"""
