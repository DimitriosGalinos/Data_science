# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 18:23:21 2020

@author: Dimitrios Galinos
"""

import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_val_score
from sklearn import preprocessing

# Reading our data sets
train_data=np.loadtxt("IDSWeedCropTrain.csv", delimiter=",")
test_data=np.loadtxt("IDSWeedCropTest.csv", delimiter=",")
# Split data into variables and labels
XTrain=train_data[:,:-1]
YTrain=train_data[:,-1]
XTest=test_data[:,:-1]
YTest=test_data[:,-1]

################################ Exercise 1 ###################################

# Set a nearest neighbor classifier
NN1=KNeighborsClassifier(n_neighbors=1)
# Train the classifier with my train data
NN1.fit(XTrain, YTrain)
# Check accuracy of our model
acc_train=NN1.score(XTrain, YTrain)
acc_test=NN1.score(XTest, YTest)
print("For our train data the accuracy of 1-NN is: "+str(acc_train))
print("For our test data the accuracy of 1-NN is: "+str(acc_test))

################################ Exercise 2 ###################################

# Set the NN classifiers
NN3=KNeighborsClassifier(n_neighbors=3)
NN5=KNeighborsClassifier(n_neighbors=5)
NN7=KNeighborsClassifier(n_neighbors=7)
NN9=KNeighborsClassifier(n_neighbors=9)
NN11=KNeighborsClassifier(n_neighbors=11)

# Calculate the average accuracy using 5-fold cross validation on our NN
# classifiers with only our Train data set
averageNNaccuracy=[None]*6
averageNNaccuracy[0]=np.mean(cross_val_score(NN1, XTrain, YTrain, cv=5))
averageNNaccuracy[1]=np.mean(cross_val_score(NN3, XTrain, YTrain, cv=5))
averageNNaccuracy[2]=np.mean(cross_val_score(NN5, XTrain, YTrain, cv=5))
averageNNaccuracy[3]=np.mean(cross_val_score(NN7, XTrain, YTrain, cv=5))
averageNNaccuracy[4]=np.mean(cross_val_score(NN9, XTrain, YTrain, cv=5))
averageNNaccuracy[5]=np.mean(cross_val_score(NN11, XTrain, YTrain, cv=5))

# See which one has the best accuracy and report it
best_acc=max(averageNNaccuracy)
kbest=2*averageNNaccuracy.index(best_acc)+1
print("\nMy k-best parameter is "+str(kbest)+" because the "
      +str(kbest)+"-NN classifier had the biggest average accuracy of " 
      +str(best_acc)+"in our 5-fold cross validation")

################################ Exercise 3 ###################################

# Train the 3-NN Classifier
NN3.fit(XTrain, YTrain)
# Perfomance of the best classifier using the test data
acc_train_3NN=NN3.score(XTrain, YTrain)
acc_test_3NN=NN3.score(XTest, YTest)
print("\nThe performance of the 3-NN Classifier for our train data is: "
      +str(acc_train_3NN))
print("The performance of the 3-NN Classifier for our test data is: "
      +str(acc_test_3NN))

################################ Exercise 4 ###################################

# Normalizing the data to Zero mean and Unit variance on my own

# Finding the mean and standard deviation
meanTrain=np.mean(XTrain, axis=0)
meanTest=np.mean(XTest, axis=0)
stdTrain=np.std(XTrain, axis=0)
stdTest=np.std(XTest, axis=0)

# Normalizing the datasets
XTrainNbyme=np.subtract(XTrain, meanTrain)/stdTrain
XTestNbyme=np.subtract(XTest, meanTest)/stdTest

# Checking the versions provided by the exercise

# version 1
scaler=preprocessing.StandardScaler().fit(XTrain)
XTrainN1=scaler.transform(XTrain)
XTestN1=scaler.transform(XTest)
# version 2
scaler=preprocessing.StandardScaler().fit(XTrain)
XTrainN2=scaler.transform(XTrain)
scaler=preprocessing.StandardScaler().fit(XTest)
XTestN2=scaler.transform(XTest)
# version 3
XTotal=np.concatenate((XTrain, XTest))
scaler=preprocessing.StandardScaler().fit(XTotal)
XTrainN3=scaler.transform(XTrain)
XTestN3=scaler.transform(XTest)

# Version 1 is flawed because the Test dataset is getting normalized using the
# mean and variance of the train dataset

# Version 2 is correct because each dataset is normalized correctly

# Version 3 is flawed because Test and Train datasets get normalized by the 
# mean and variance of their concat instead of their own indidividual mean
# and std.

print("\nI have calculated XTrain's and XTest's mean and standard deviation "+
      "normalized both of the by subracting their respective means and "+
      "dividing by their respecting std's in order to reach a zero mean and "+
      "unit variance normalization which yields the same results as "+
      "the version 2 of preprocessing from the exercise")

# Here I repeat code from 2 and 3
averageNNaccuracy[0]=np.mean(cross_val_score(NN1, XTrainN2, YTrain, cv=5))
averageNNaccuracy[1]=np.mean(cross_val_score(NN3, XTrainN2, YTrain, cv=5))
averageNNaccuracy[2]=np.mean(cross_val_score(NN5, XTrainN2, YTrain, cv=5))
averageNNaccuracy[3]=np.mean(cross_val_score(NN7, XTrainN2, YTrain, cv=5))
averageNNaccuracy[4]=np.mean(cross_val_score(NN9, XTrainN2, YTrain, cv=5))
averageNNaccuracy[5]=np.mean(cross_val_score(NN11, XTrainN2, YTrain, cv=5))

best_acc=max(averageNNaccuracy)
kbest=2*averageNNaccuracy.index(best_acc)+1
print("\nMy k-best parameter for the normalized data is "+str(kbest)+
      " because the "+str(kbest)+
      "-NN classifier had the biggest average accuracy of "+str(best_acc)+
      "in our 5-fold cross validation")

# Train the 3-NN Classifier
NN3.fit(XTrainN2, YTrain)
# Perfomance of the best classifier using the test data
acc_train_3NN=NN3.score(XTrainN2, YTrain)
acc_test_3NN=NN3.score(XTestN2, YTest)
print("\nThe performance of the 3-NN Classifier with normalization for our "+
      "train data is: "+str(acc_train_3NN))
print("The performance of the 3-NN Classifier with normalization for our "+
      "test data is: "+str(acc_test_3NN))