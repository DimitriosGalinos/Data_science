Introduction to Data Science Assignment 2

The code is in the file named assignment2.py

Libraries used are numpy and sklearn for the KNeighborsClassifier, 
cross_val_score and the preprocessing

In order to run the code you simply need to load them to a python interpreter 
like Spyder or in a cmd promth and execute them while having the dataset in the
same directory (I will include the datasets in the code.zip).

