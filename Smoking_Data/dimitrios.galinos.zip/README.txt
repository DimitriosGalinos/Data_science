Introduction to Data Science Assignment 1

The code is in the file named assignment1.py

Libraries used are numpy, matplotlib.pyplot, scipy.stats and I also use from
the math library sqrt() for the square root and floor() for getting the 
rounded floor of an integer.

In order to run the code you simply need to load them to a python interpreter 
like Spyder and execute them while having the dataset in the same directory 
(I will include the datasets in the code.zip).

