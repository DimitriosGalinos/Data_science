# input: datamatrix as loaded by numpy.loadtxt('dataset.txt')
# output:  1) the eigenvalues in a vector (numpy array) in descending 
#             order
#          2) the unit eigenvectors in a matrix (numpy array) with each 
#             column being an eigenvector (in the same order as its associated 
#             eigenvalue)
#
# note: make sure the order of the eigenvalues (the projected variance) is 
#       decreasing, and the eigenvectors have the same order as their 
#       associated eigenvalues

import numpy as np

def pca(data):
    # Finding the number of dimensions
    lenght=np.size(data, 1)
    # Centrailizing our dataset
    centralized=np.array(data)
    for xx in range(lenght):
        centralized[:,xx]=data[:,xx]-np.mean(data[:,xx])
    # Finding the Covariance Matrix
    cc=np.cov(centralized.T)
    # Calculating the eigenvalues & eigenvectors
    evals, evecs = np.linalg.eig(cc)
    # Sort values+vectors
    idx = evals.argsort()[::-1]  
    eigenValues = evals[idx]
    eigenVectors = evecs[:,idx]
    return eigenValues, eigenVectors, idx