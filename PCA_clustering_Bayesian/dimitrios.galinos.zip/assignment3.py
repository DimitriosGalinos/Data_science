# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 16:09:39 2020

@author: Dimitrios Galinos
"""

import numpy as np
from pca import pca
from mds import mds
import matplotlib.pyplot as plt
from math import sqrt
from sklearn.cluster import KMeans 

# Reading our data sets
murderdata=np.loadtxt('murderdata2d.txt')
train_data=np.loadtxt("IDSWeedCropTrain.csv", delimiter=",")
test_data=np.loadtxt("IDSWeedCropTest.csv", delimiter=",")
# Split data into variables and labels
XTrain=train_data[:,:-1]
YTrain=train_data[:,-1]
XTest=test_data[:,:-1]
YTest=test_data[:,-1]
# Standardize the dataset I'm gonna use
meanTrain=np.mean(XTrain, axis=0)
stdTrain=np.std(XTrain, axis=0)
XTrain=np.subtract(XTrain, meanTrain)/stdTrain
meanmurder=np.mean(murderdata, axis=0)
stdmurder=np.std(murderdata, axis=0)
murderdata=np.subtract(murderdata, meanmurder)/stdmurder

################################ Exercise 1 ##################################

# Do PCA for the weed and murder data sets
eigenValuesmurder, eigenVectorsmurder, indexesmurder=pca(murderdata)
eigenValuesweed, eigenVectorsweed, indexesweed=pca(XTrain)

# Plot the murder dataset, the mean and the arros
plt.scatter(murderdata[:,0], murderdata[:,1], color="lightblue")

x_mean=np.mean(murderdata[:,0])
y_mean=np.mean(murderdata[:,1])

plt.scatter(x_mean, y_mean, color="black")

pc1_s=sqrt(eigenValuesmurder[0])
pc2_s=sqrt(eigenValuesmurder[1])
plt.plot([x_mean, pc1_s*eigenVectorsmurder[0,0]], 
         [y_mean, pc1_s*eigenVectorsmurder[1,0]], 'red')
plt.plot([x_mean, pc2_s*eigenVectorsmurder[0,1]], 
         [y_mean, pc2_s*eigenVectorsmurder[1,1]], 'orange')
plt.xlabel('Percentage of unemployement')
plt.ylabel('Murders per annum per 1,000,000 inhabitants')
plt.show()

# Plot of variance explained by the PCs in the weed dataset
eigen_len=[1,2,3,4,5,6,7,8,9,10,11,12,13]
plt.plot(eigen_len, eigenValuesweed)
plt.ylabel('Variance')
plt.xlabel('Principal Component')
plt.show()

# Find how many PCs in the weed dataset I need for 90% and 95% of the variance
var_sum=sum(eigenValuesweed)
normalized_weed=eigenValuesweed/var_sum
cummulative_var=[None]*len(normalized_weed)
idx90=0
flag90=0
idx95=0
flag95=0
for xx in range(len(normalized_weed)):
    if xx==0:
        cummulative_var[xx]=normalized_weed[xx]
        if cummulative_var[xx]>0.90:
            idx90=1
            flag90=1
        if cummulative_var[xx]>0.95:
            idx95=1
            flag95=1
    else:
        cummulative_var[xx]=normalized_weed[xx]+cummulative_var[xx-1]
        if cummulative_var[xx]>0.90 and flag90==0:
            idx90=xx+1
            flag90=1
        if cummulative_var[xx]>0.95 and flag95==0:
            idx95=xx+1
            flag95=1
            
# Plot the cumulative variance of the PCs in the weed dataset
plt.plot(eigen_len, cummulative_var)
plt.ylabel('Cumulative Variance')
plt.xlabel('Principal Component')
plt.show()
print("I need "+str(idx90)+" PCs in order to capture 90% of the variance")
print("\nI need "+str(idx95)+" PCs in order to capture 95% of the variance")


"""
I used that part to cross-check my results with the PCA library

from sklearn.decomposition import PCA

pca = PCA(n_components=2)
haha=pca.fit_transform(XTrain)
print(pca.components_)
print(pca.explained_variance_)
plt.scatter(haha[:,0], haha[:,1])
plt.xlabel('1st Principal component (Feature 1)')
plt.ylabel('2nd Principal component (Feature 2)')
plt.show()
"""

################################ Exercise 2 ##################################

new_weed=mds(XTrain, 2)
plt.scatter(new_weed[:,0], new_weed[:,1])
plt.xlabel('1st Principal component (Feature 1)')
plt.ylabel('2nd Principal component (Feature 2)')
plt.show()

################################ Exercise 3 ##################################

start=np.vstack((XTrain[0,:], XTrain[1,:]))
kmeans=KMeans(n_clusters=2, n_init=1, init=start, 
              algorithm="full").fit(XTrain)
print("\nThe two cluster centers are:\n"+str(kmeans.cluster_centers_))

