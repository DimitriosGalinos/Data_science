Introduction to Data Science Assignment 2

The code is in the files named assignment3.py (main execution), mds.py 
and pca.py

Libraries used are numpy, matplotlib, math for the square root
and sklearn.cluster for the KMeans clustering. 

The main file is dependant on mds.py & pca.py and mds.py is dependant of pca.py

In order to run the code you simply need to load them to a python interpreter 
like Spyder or in a cmd prompt and execute them while having the dataset in the
same directory (I will include the datasets in the code.zip).

